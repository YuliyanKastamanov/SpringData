public enum Constant {

    ;
    static final String DATABASE_NAME = "soft_uni";
}
